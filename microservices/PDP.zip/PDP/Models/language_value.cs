﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace cdp_api.Models
{
    public class language_value
    {
        public string language { get; set; }
        public string value { get;set; }
    }
}
