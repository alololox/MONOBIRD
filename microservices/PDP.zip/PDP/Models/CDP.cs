﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cdp_api.models
{
    public class CDP
    {
     //   public recordsRecord Original {get;set;}
        public string Name { get; set; }
    }
}
